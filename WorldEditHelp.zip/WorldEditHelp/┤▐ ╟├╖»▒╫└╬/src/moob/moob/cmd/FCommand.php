<?php

namespace FCommand\FCommand\cmd;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use ARDRPlugin\ARDRPlugin\form\admin\Main;

class FCommand extends Command{
	public function __construct(){
		parent::__construct("달", "달관련");
		$this->setPermission('admin.cmd');
	}
	public function execute(CommandSender $p, string $label, array $args): bool{
		if (! Server::getInstance()->isOP($p->getName())){
			return true;
		}
    }
}