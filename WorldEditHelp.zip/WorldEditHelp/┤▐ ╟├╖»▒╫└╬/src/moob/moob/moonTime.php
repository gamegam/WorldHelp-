<?php
namespace moob\moob;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class moonTime extends Task{
    public function onRun():void{
        $this->time();
    }

    public function time(){
        $api = Server::getInstance()->getPluginManager()->getPlugin("moob");
        Server::getInstance()->getWorldManager()->getWorldByName($api->db["map"])->setTime(18000);
    }
}