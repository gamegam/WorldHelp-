<?php

namespace moob\moob;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\event\player\{PlayerMoveEvent, PlayerJumpEvent, PlayerInteractEvent};
use pocketmine\Server;
use pocketmine\player\Player;
use moob\moob\map\moonmap;
use pocketmine\world\WorldCreationOptions;
use pocketmine\world\generator\GeneratorManager;
use pocketmine\math\Vector3;
use pocketmine\item\LegacyStringToItemParser;
use pocketmine\event\entity\{EntityTeleportEvent, EntityDamageEvent};

use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\block\Block;
class Main extends PluginBase implements Listener{

    public $tag = "§b[알림]§7 ";

    public function onEnable():void{
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->data = new Config($this->getDataFolder(). "Data.yml",Config::YAML, ["map" => "moon"]);
        $this->db = $this->data->getAll();

        $this->getScheduler()->scheduleRepeatingTask(new moonTime, 0);
        $this->world();
    }

    public function hp(Player $p, Block $pos){
        $ps = $p->getPosition();
        $block = $pos->getPosition();
        $distance = $block->distance($ps); // 거리 계산
        $hp = 0.2;
        if ($distance > 3 and $distance < 7){
            $hp = 4.5;
        }elseif ($distance > 1.6 and $distance < 2.9){
            $hp = 5.8;
        }elseif ($distance < 1.5){
            $hp = 100;
        }
        $p->setHealth($p->getHealth() - $hp); // 체력 감소
        $this->msg($p, "수압이 강력해서 물이 증발되었고 주변이 폭발되었습니다.({$hp})피해를 입었습니다.");
    }

    public function D(PlayerInteractEvent $ev){
        $p = $ev->getPlayer();
        $item = $p->getInventory()->getItemInHand();
        $id = $item->getTypeId();
        $a = $ev->getBlock()->getPosition();
        if ($id == 20142){
            $count = $item->setCount(1);
            $p->getInventory()->removeItem($count);
            $this->msg($p, "밑 블럭까지 녹았습니다.");
            for($i =0; $i <= 10; $i++){           
                $p->getWorld()->setBlock(new Vector3($a->getX(), $a->getY() - $i, $a->getZ()), VanillaBlocks::AIR());
                $ev->cancel();
            }
        }
    }
    
    public function PlayerInteractEvent(PlayerInteractEvent $ev){
        $p = $ev->getPlayer();
        $item = $p->getInventory()->getItemInHand();
        $id = $item->getTypeId();
        $a = $ev->getBlock()->getPosition();
        //$p->sendMessage($id.":". $item);
        if ($id == 20218 and $p->getWorld()->getFolderName() == $this->db["map"]){
            $ev->cancel();
            $count = $item->setCount(1);
            $p->getInventory()->removeItem($count);
           // $this->msg($p, "수압이 강력해서 물이 증발되었고 주변이 폭발되었습니다.");
            $this->hp($p, $ev->getBlock());
            for ($x = 1; $x <= 3; $x ++){
                $p->getWorld()->setBlock(new Vector3($a->getX() + $x, $a->getY(), $a->getZ()), VanillaBlocks::AIR());
                $p->getWorld()->setBlock(new Vector3($a->getX() - $x, $a->getY(), $a->getZ()), VanillaBlocks::AIR());
                for($y = 1; $y <=3; $y++){
                    $p->getWorld()->setBlock(new Vector3($a->getX(), $a->getY() + $y, $a->getZ()), VanillaBlocks::AIR());
                    $p->getWorld()->setBlock(new Vector3($a->getX(), $a->getY() - $y, $a->getZ()), VanillaBlocks::AIR());
                    for($z = 1; $z <=3; $z ++){
                        $p->getWorld()->setBlock(new Vector3($a->getX(), $a->getY(), $a->getZ() + $z), VanillaBlocks::AIR());
                        $p->getWorld()->setBlock(new Vector3($a->getX(), $a->getY(), $a->getZ() - $z), VanillaBlocks::AIR());
                    }
                }
            }
        }
    }

    public function save():void{
        $this->data->setAll($this->db);
        $this->data->save();
    }

    public function msg(Player $p, $msg){
        $p->sendMessage($this->tag. $msg);
    }

    public function EntityDamageEvent(EntityDamageEvent $ev){
        $p = $ev->getEntity();
        $use = $ev->getCause();
        if ($p instanceof Player){
            if ($use == 4){
                if ($p->getWorld()->getFolderName() == $this->db["map"]){
                    $ev->cancel();
                }
            }
        }
    }

    public function Teleport(EntityTeleportEvent $ev){
        $p = $ev->getEntity();
        if ($p instanceof Player){
            $world = $p->getWorld()->getFolderName();
            $name = strtolower($p->getName());
            if ($world !== $this->db["map"]){
                unset($this->db[$name]["달입장"]);
            }
        }
    }

    public function world(){
        if(GeneratorManager::getInstance()->getGenerator('moonmap') === null){
            GeneratorManager::getInstance()->addGenerator(moonmap::class, $this->db["map"], fn() => null);     
        }
        if(Server::getInstance()->getWorldManager()->loadWorld('moon') === null){
        $void = moonmap::class;
        $pos = new Vector3(255, 60, 255);
        Server::getInstance()->getWorldManager()->generateWorld('moon', WorldCreationOptions::create()->setSeed(1234)->setGeneratorClass($void)->setSpawnPosition($pos));
        }
    }

    public function PlayerJumpEvent(PlayerJumpEvent $ev){
        $p = $ev->getPlayer();
        $name = strtolower($p->getName());
        $pos = $p->getPosition();
        $speed = $p->getMotion();
        $speed->y += 1.5;
        $world = $p->getWorld()->getFolderName();
        if (isset($this->db[$name]["달입장"])){
            if ($world == $this->db["map"]){
                $p->setMotion($speed);
            }
        }
    }

    public function PlayerMoveEbent(PlayerMoveEvent $ev){
        $p = $ev->getPlayer();
        $pos = $p->getPosition();
        $y = $pos->getY();
        $name = strtolower($p->getName());
        $block = $p->getWorld()->getBlock($p->getPosition()->add(0.5, 0, 0.5)->subtract(0, 1, 0));
        $world = $p->getWorld()->getFolderName();
        if ($y > 300 and $world !== "moon"){
            if (! Server::getInstance()->getWorldManager()->getWorldByName($this->db["map"])){
                $this->msg($p, "달을(를) 찾을 수 없습니다.(콘솔을 확인해주세요!)");
                Server::getInstance()->getLogger()->info("§c달 월드(moon)이(가) 로드 되지 않았거나 또는 월드가 존재하지 않습니다.");
                return true;
            }
            $p->teleport(Server::getInstance()->getWorldManager()->getWorldByName($this->db["map"])->getSafeSpawn());
            $this->db[$name]["달입장"] = true;
            $this->save();
        }
        if ($world !== $this->db["map"]){
            unset($this->db[$name]["달입장"]); 
        }else{
            $this->db[$name]["달입장"] = true;
        }
    }
}