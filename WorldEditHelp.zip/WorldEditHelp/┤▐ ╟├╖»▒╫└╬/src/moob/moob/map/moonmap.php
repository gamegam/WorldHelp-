<?php

namespace moob\moob\map;

use pocketmine\world\ChunkManager;
use pocketmine\world\generator\Generator;

class moonmap extends Generator{
    public function __construct(int $seed, string $preset){
        parent::__construct($seed, $preset);
    }

    /**
     * 섬 플러그인 참조
     */
    public function generateChunk(ChunkManager $world, int $chunkX, int $chunkZ) : void {}
    public function populateChunk(ChunkManager $world, int $chunkX, int $chunkZ) : void {}
}